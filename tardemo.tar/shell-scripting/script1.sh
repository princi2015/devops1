myvR='shell scripting'
echo $myvar

